package Tic_Tac_Toe;
class config {
	// SWidth must Smaller Than SHeight
	int SWidth = 400;
	int SHeight = 450;
	int WPanel = SWidth*3/4;
	int Weight = WPanel/3;
	int BorderWidth = SWidth/8;
	int fontWeight = 5;
}